document.addEventListener('DOMContentLoaded', function () {
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    const popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl, {
            trigger: 'hover focus' // Exibe o popover ao passar o mouse ou focar a imagem
        });
    });

    const carouselElement = document.querySelector('#carouselExampleIndicators');
    const carousel = new bootstrap.Carousel(carouselElement, {
        interval: 10000,
        ride: 'carousel'
    });
});

$(document).ready(function() {
    $('#orcamento-form').submit(function(event) {
        event.preventDefault(); // Impede o envio padrão do formulário

        // Cria um objeto de dados do formulário
        var formData = $(this).serialize();

        // Faz uma solicitação AJAX usando jQuery
        $.ajax({
            url: $(this).attr('action'),
            method: 'POST',
            data: formData,
            dataType: 'json',
            success: function() {
                console.log('Formulário enviado com sucesso!');
                window.location.href = 'obrigado.html'; // Redireciona para a página de agradecimento
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.error('Erro ao enviar o formulário: ', textStatus, errorThrown);
                alert('Ocorreu um erro. Por favor, tente novamente.');
            }
        });
    });
});
